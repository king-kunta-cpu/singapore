# Coldcode Si Labs Library — public website redesign

A static, responsive storefront built around the 29 redesigned covers. It includes the homepage, catalogue, 29 title pages, About, a My Shelf handoff, and a 404 page. The base catalogue is in the HTML; JavaScript adds search, category filters and sorting. All fonts, styles and cover images are local. Images are optimized WebP versions of the supplied covers.

## Preview locally

From this folder, run `python3 serve.py --port 4173` and open `http://localhost:4173/` in a browser. Opening `index.html` as a file won't work because the site uses root-relative URLs. To edit catalogue copy or prices, update `catalogue.json` and run `python3 build.py`. You can edit the design in `assets/style.css` and interactions in `assets/site.js`. Python dependencies: standard library only.

## Publish safely

The current Worker at `library.coldcode-si-labs.workers.dev` is **unchanged**. This package is the public frontend, not a replacement Worker. It contains no credentials, paid books, order data, or account logic.

- **Separate staging/static host:** serve `index.html`, `404.html`, `assets/`, `catalogue/`, `preview/`, `about/` and `shelf/` at the root. Use directory index routing; URLs such as `/preview/thesis/` serve that directory's `index.html`. Don't expose source files or the local server script.
- **Integrate into the existing Worker:** review the Worker source and its routing first. Serve the new public pages and assets only for known public paths. Preserve the existing `/claim` flow, the order, reader and download endpoints it depends on, and `/samples/*` and existing `/covers/*` routes. Keep old incoming `/preview/<slug>` links working, by serving the new title page or redirecting to the trailing-slash version. Test in staging before switching production traffic; don't deploy this folder over the existing Worker as a whole.
- **Existing services:** all order links use the live Whop product URLs. Sample links use the existing `/samples/<slug>.pdf` URLs. The `/shelf/` page directs customers to the original `/claim` flow and does not request private receipt details itself, even in preview. Actual paid orders and sign-ins were not performed in testing.
- **Indexing:** the generated pages keep the existing storefront's `noindex,nofollow` setting. Review that choice in `build.py` before a public search-engine launch.

## Verification

The 29 local detail routes and all 29 live sample PDF URLs returned HTTP 200. Browser testing covered mobile navigation, global and catalogue search, category filters, price sorting, book detail links, the shelf handoff, and 404 status. Main templates were checked for horizontal overflow at 320, 390, 680, 768, 1024 and 1440 px.
