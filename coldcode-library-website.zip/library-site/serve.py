"""Local preview server. No external dependencies, credentials, or API keys."""
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import argparse, os
root=Path(__file__).resolve().parent
class Handler(SimpleHTTPRequestHandler):
    def send_error(self, code, message=None, explain=None):
        if code==404:
            body=(root/'404.html').read_bytes();self.send_response(404);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Content-Length',str(len(body)));self.end_headers()
            if self.command!='HEAD': self.wfile.write(body)
        else: super().send_error(code,message,explain)
parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=4173);parser.add_argument('--host',default='0.0.0.0');args=parser.parse_args()
os.chdir(root);print(f'Library preview on port {args.port}',flush=True);ThreadingHTTPServer((args.host,args.port),Handler).serve_forever()
