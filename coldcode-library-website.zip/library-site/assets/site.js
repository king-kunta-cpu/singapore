'use strict';
document.documentElement.classList.add('enhanced');
const menu = document.querySelector('.menu-toggle');
const nav = document.getElementById('site-nav');
function setMenu(open) { nav.classList.toggle('open',open); menu.setAttribute('aria-expanded',String(open)); }
menu.addEventListener('click',()=>setMenu(menu.getAttribute('aria-expanded')!=='true'));
nav.addEventListener('click',event=>{ if(event.target.closest('a'))setMenu(false); });
document.addEventListener('keydown',event=>{
  if(event.key==='Escape' && menu.getAttribute('aria-expanded')==='true'){setMenu(false);menu.focus();}
});
document.addEventListener('click',event=>{if(menu.getAttribute('aria-expanded')==='true'&&!event.target.closest('.header'))setMenu(false);});
const search = document.getElementById('search-dialog');
const trigger = document.querySelector('.search-trigger');
trigger.addEventListener('click',()=>{ if(!search.open){search.showModal(); document.getElementById('quick-search').focus();} });
search.addEventListener('click',event=>{if(event.target===search){const r=search.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)search.close();}});
document.addEventListener('keydown',event=>{
  if(event.key==='/'&&!event.ctrlKey&&!event.metaKey&&!event.altKey&&!search.open&&!event.target.closest?.('input,textarea,select,[contenteditable]')){event.preventDefault();trigger.click();}
});
const grid=document.getElementById('catalogue-results');
if(grid){
  const buttons=[...document.querySelectorAll('[data-filter]')];
  const cards=[...grid.children];
  const field=document.getElementById('catalogue-search');
  const sort=document.getElementById('sort');
  const count=document.getElementById('result-count');
  const empty=document.querySelector('.empty');
  const mainNav=[...nav.querySelectorAll('a')];
  const allowed=['all','series','books','papers'];
  const sortKeys=['catalogue','title','low','high'];
  const format=value=>value.toLowerCase().normalize('NFD').replace(/\p{Diacritic}/gu,'');
  for(const card of cards)card.searchTokens=card.dataset.text.match(/[\p{L}\p{N}]+/gu)||[];
  let type='all';
  function fromUrl(){
    const params=new URLSearchParams(location.search);
    type=allowed.includes(params.get('type')) ? params.get('type') : 'all';
    field.value=params.get('q')||'';
    sort.value=sortKeys.includes(params.get('sort'))?params.get('sort'):'catalogue';
  }
  function render(updateURL=false){
    const q=field.value.trim();
    const words=format(q).match(/[\p{L}\p{N}]+/gu)||[];
    let n=0;
    const order=[...cards];
    if(sort.value==='title')order.sort((a,b)=>a.dataset.title.localeCompare(b.dataset.title));
    if(sort.value==='low'||sort.value==='high')order.sort((a,b)=>(Number(a.dataset.price)-Number(b.dataset.price))*(sort.value==='low'?1:-1));
    for(const card of order){
      const show=(type==='all'||card.dataset.group===type)&&words.every(word=>card.searchTokens.some(token=>word.length<=2?token===word:token.startsWith(word)));
      card.hidden=!show;
      grid.append(card);
      if(show)n++;
    }
    const nextCount=`${n} ${n===1?'title':'titles'}${q?' found':''}`;
    if(count.textContent!==nextCount)count.textContent=nextCount;
    empty.hidden=n!==0;
    buttons.forEach(button=>button.setAttribute('aria-pressed',String(button.dataset.filter===type)));
    mainNav.forEach(a=>{if(a.getAttribute('href')===(type==='papers'?'/catalogue/?type=papers':'/catalogue/'))a.setAttribute('aria-current','page');else a.removeAttribute('aria-current');});
    if(updateURL){
      const params=new URLSearchParams();
      if(type!=='all')params.set('type',type);
      if(q)params.set('q',q);
      if(sort.value!=='catalogue')params.set('sort',sort.value);
      history.replaceState(null,'',location.pathname+(params.size?'?'+params.toString():'')+location.hash);
    }
  }
  fromUrl(); render(); document.querySelector('.catalogue-controls').hidden=false;
  field.addEventListener('input',()=>render(true)); sort.addEventListener('change',()=>render(true));
  buttons.forEach(button=>button.addEventListener('click',()=>{type=button.dataset.filter;render(true);}));
  document.getElementById('clear-filters').addEventListener('click',()=>{field.value='';type='all';sort.value='catalogue';render(true);field.focus();});
  window.addEventListener('popstate',()=>{fromUrl();render();});
}
